courses = []
def add_course(c_name, c_duration, c_price, a_members):
    course = {
        'c_name': c_name,
        'c_duration': c_duration,
        'c_price': c_price,
        'a_members': a_members
    }
    courses.append(course)
def print_separator():
    print("+------------------+------------------+---------------+-----------------+")
def check_course_exist(c_name):
    for course in courses:
        if course['c_name'] == c_name:
            return True
    return False
def courses_with_less_than_50_seats():
    count = 0
    for course in courses:
        if course['a_members'] < 50:
            count += 1
    return count
def courses_with_price_above_1000():
    count = 0
    for course in courses:
        if course['c_price'] > 1000:
            count += 1
    return count
def total_courses():
    return len(courses)
def total_seats():
    total = 0
    for course in courses:
        total += course['a_members']
    return total
n = int(input("Enter the number of courses: "))
for _ in range(n):
    c_name = input("Enter course name: ")
    c_duration = int(input("Enter course duration (in weeks): "))
    c_price = int(input("Enter course price: "))
    a_members = int(input("Enter admitted members: "))
    add_course(c_name, c_duration, c_price, a_members)
print_separator()
print("|   Course Name    | Duration (weeks) | Price ($) | Admitted Members |")
print_separator()
for course in courses:
    print("| {:<16} | {:<16} | {:<10} | {:<16} |".format(
        course['c_name'],
        course['c_duration'],
        course['c_price'],
        course['a_members']
    ))
print_separator()
print("Second course name:", courses[1]['c_name'])
course_name_to_check = input("Enter the course name to check if it exists: ")
if check_course_exist(course_name_to_check):
    print(f"The course '{course_name_to_check}' exists.")
else:
    print(f"The course '{course_name_to_check}' does not exist.")
print("Courses with less than 50 seats:", courses_with_less_than_50_seats())
print("Courses with price above 1000:", courses_with_price_above_1000())
print("Total number of courses:", total_courses())
print("Total number of seats in the college:", total_seats())
sorted_courses_by_name = sorted(courses, key=lambda x: x['c_name'])
print("Courses sorted by name:")
for course in sorted_courses_by_name:
    print(course['c_name'])
sorted_prices = sorted([course['c_price'] for course in courses])
print("\nPrices sorted:")
for price in sorted_prices:
    print(price)

