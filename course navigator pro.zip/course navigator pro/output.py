Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:\Users\surekha\OneDrive\Desktop\final.py
Enter the number of courses: 20
Enter course name: c
Enter course duration (in weeks): 3
Enter course price: 7000
Enter admitted members: 34
Enter course name: python
Enter course duration (in weeks): 7
Enter course price: 8000
Enter admitted members: 56
Enter course name: java
Enter course duration (in weeks): 9
Enter course price: 8000
Enter admitted members: 67
Enter course name: c++
Enter course duration (in weeks): 6
Enter course price: 6000
Enter admitted members: 25
Enter course name: html
Enter course duration (in weeks): 6
Enter course price: 8000
Enter admitted members: 56
Enter course name: java full stack
Enter course duration (in weeks): 6
Enter course price: 10000
Enter admitted members: 45
Enter course name: sql
Enter course duration (in weeks): 6
Enter course price: 6000
Enter admitted members: 56
Enter course name: dbms
Enter course duration (in weeks): 6
Enter course price: 5000
Enter admitted members: 67
Enter course name: oops
Enter course duration (in weeks): 9
Enter course price: 12000
Enter admitted members: 45
Enter course name: full stack
Enter course duration (in weeks): 5
Enter course price: 6000
Enter admitted members: 34
Enter course name: python full stack
Enter course duration (in weeks): 7
Enter course price: 8000
Enter admitted members: 65
Enter course name: os
Enter course duration (in weeks): 8
Enter course price: 6500
Enter admitted members: 54
Enter course name: perl
Enter course duration (in weeks): 5
Enter course price: 8000
Enter admitted members: 54
Enter course name: visual basic
Enter course duration (in weeks): 5
Enter course price: 6000
Enter admitted members: 43
Enter course name: copol
Enter course duration (in weeks): 4
Enter course price: 5000
Enter admitted members: 34
Enter course name: nosql
Enter course duration (in weeks): 4
Enter course price: 7000
Enter admitted members: 23
Enter course name: c-sharp
Enter course duration (in weeks): 6
Enter course price: 6000
Enter admitted members: 46
Enter course name: rust
Enter course duration (in weeks): 5
Enter course price: 5000
Enter admitted members: 45
Enter course name: c#
Enter course duration (in weeks): 7
Enter course price: 8000
Enter admitted members: 56
Enter course name: kotlin
Enter course duration (in weeks): 4
Enter course price: 6000
Enter admitted members: 67
+------------------+------------------+---------------+-----------------+
|   Course Name    | Duration (weeks) | Price ($) | Admitted Members |
+------------------+------------------+---------------+-----------------+
| c                | 3                | 7000       | 34               |
| python           | 7                | 8000       | 56               |
| java             | 9                | 8000       | 67               |
| c++              | 6                | 6000       | 25               |
| html             | 6                | 8000       | 56               |
| java full stack  | 6                | 10000      | 45               |
| sql              | 6                | 6000       | 56               |
| dbms             | 6                | 5000       | 67               |
| oops             | 9                | 12000      | 45               |
| full stack       | 5                | 6000       | 34               |
| python full stack | 7                | 8000       | 65               |
| os               | 8                | 6500       | 54               |
| perl             | 5                | 8000       | 54               |
| visual basic     | 5                | 6000       | 43               |
| copol            | 4                | 5000       | 34               |
| nosql            | 4                | 7000       | 23               |
| c-sharp          | 6                | 6000       | 46               |
| rust             | 5                | 5000       | 45               |
| c#               | 7                | 8000       | 56               |
| kotlin           | 4                | 6000       | 67               |
+------------------+------------------+---------------+-----------------+
Second course name: python
Enter the course name to check if it exists: java
The course 'java' exists.
Courses with less than 50 seats: 10
Courses with price above 1000: 20
Total number of courses: 20
Total number of seats in the college: 972
Courses sorted by name:
c
c#
c++
c-sharp
copol
dbms
full stack
html
java
java full stack
kotlin
nosql
oops
os
perl
python
python full stack
rust
sql
visual basic

Prices sorted:
5000
5000
5000
6000
6000
6000
6000
6000
6000
6500
7000
7000
8000
8000
8000
8000
8000
8000
10000
12000
